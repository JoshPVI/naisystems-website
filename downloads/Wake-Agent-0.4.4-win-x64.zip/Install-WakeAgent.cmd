@echo off
start "" "%~dp0WakeAgent.exe" --install
